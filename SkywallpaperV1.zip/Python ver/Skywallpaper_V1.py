import os
import sys
import random
import tempfile
import ctypes
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

# Check for the Pillow dependency required for advanced image formats (.png, .webp, etc.)
try:
    from PIL import Image, ImageTk
except ImportError:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror(
        "Missing Dependency",
        "The 'Pillow' library is required to handle various image formats.\n\n"
        "Please install it by running the following command in your terminal:\n"
        "pip install Pillow"
    )
    sys.exit(1)


class SkyWallpaperApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SkyWallpaper")
        self.root.geometry("850x550")
        self.root.minsize(700, 450)

        # Resolve wallpapers directory relative to the script location
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.wallpapers_dir = os.path.join(self.script_dir, "wallpapers")

        # Automatically create the wallpapers folder if it does not exist
        if not os.path.exists(self.wallpapers_dir):
            try:
                os.makedirs(self.wallpapers_dir)
            except Exception:
                pass

        self.image_files = []
        self.current_index = 0
        self.auto_rotate_job = None
        self.preview_image = None

        self.create_widgets()
        self.load_images_from_folder(self.wallpapers_dir)

    def create_widgets(self):
        # Main layout using a PanedWindow for resizable split view
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Left Frame: Folder selection and Wallpaper List
        left_frame = ttk.Frame(main_paned, padding=5)
        main_paned.add(left_frame, weight=1)

        folder_btn = ttk.Button(left_frame, text="Select Wallpaper Folder", command=self.select_folder)
        folder_btn.pack(fill=tk.X, pady=(0, 5))

        self.folder_label = ttk.Label(left_frame, text=f"Folder: {self.wallpapers_dir}", font=("Arial", 9))
        self.folder_label.pack(fill=tk.X, pady=(0, 5))

        list_frame = ttk.Frame(left_frame)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))

        self.listbox = tk.Listbox(list_frame, selectmode=tk.SINGLE, font=("Arial", 10))
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.listbox.bind("<<ListboxSelect>>", self.on_select_image_from_list)

        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.listbox.config(yscrollcommand=scrollbar.set)

        # Right Frame: Preview and Controls
        right_frame = ttk.Frame(main_paned, padding=5)
        main_paned.add(right_frame, weight=1)

        # Preview Image Area
        self.preview_label = ttk.Label(right_frame, text="No Preview Available", background="#222222", foreground="#ffffff", anchor=tk.CENTER)
        self.preview_label.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # Action Buttons Frame
        btn_frame = ttk.LabelFrame(right_frame, text="Controls", padding=10)
        btn_frame.pack(fill=tk.X, pady=(0, 10))

        self.apply_btn = ttk.Button(btn_frame, text="Set as Wallpaper", command=self.apply_current_wallpaper)
        self.apply_btn.grid(row=0, column=0, columnspan=2, sticky="ew", padx=2, pady=2)

        prev_btn = ttk.Button(btn_frame, text="Previous", command=self.prev_wallpaper)
        prev_btn.grid(row=1, column=0, sticky="ew", padx=2, pady=2)

        next_btn = ttk.Button(btn_frame, text="Next", command=self.next_wallpaper)
        next_btn.grid(row=1, column=1, sticky="ew", padx=2, pady=2)

        rand_btn = ttk.Button(btn_frame, text="Random", command=self.random_wallpaper)
        rand_btn.grid(row=2, column=0, columnspan=2, sticky="ew", padx=2, pady=2)

        btn_frame.columnconfigure(0, weight=1)
        btn_frame.columnconfigure(1, weight=1)

        # Auto-Rotate Frame
        rotate_frame = ttk.LabelFrame(right_frame, text="Automatic Rotation", padding=10)
        rotate_frame.pack(fill=tk.X, pady=(0, 5))

        self.auto_rotate_var = tk.BooleanVar(value=False)
        self.auto_check = ttk.Checkbutton(rotate_frame, text="Enable Auto-Rotate", variable=self.auto_rotate_var, command=self.toggle_auto_rotate)
        self.auto_check.pack(anchor=tk.W, pady=(0, 5))

        interval_frame = ttk.Frame(rotate_frame)
        interval_frame.pack(fill=tk.X)

        ttk.Label(interval_frame, text="Interval (minutes):").pack(side=tk.LEFT, padx=(0, 5))
        self.interval_spin = ttk.Spinbox(interval_frame, from_=1, to=1440, width=5)
        self.interval_spin.set(10)
        self.interval_spin.pack(side=tk.LEFT)

        # Status Bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W, padding=4)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def load_images_from_folder(self, folder_path):
        self.wallpapers_dir = folder_path
        self.folder_label.config(text=f"Folder: {self.wallpapers_dir}")
        self.image_files = []
        self.listbox.delete(0, tk.END)

        valid_extensions = (".jpg", ".jpeg", ".png", ".bmp", ".webp")

        if not os.path.exists(folder_path):
            self.status_var.set("Wallpaper folder does not exist.")
            return

        try:
            files = sorted(os.listdir(folder_path))
            for file in files:
                if file.lower().endswith(valid_extensions):
                    full_path = os.path.join(folder_path, file)
                    if os.path.isfile(full_path):
                        self.image_files.append(full_path)
                        self.listbox.insert(tk.END, file)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read wallpaper folder:\n{e}")
            return

        if self.image_files:
            self.listbox.selection_set(0)
            self.current_index = 0
            self.update_preview(self.image_files[0])
            self.status_var.set(f"Loaded {len(self.image_files)} wallpaper(s).")
        else:
            self.preview_label.config(image="", text="No images found in folder")
            self.preview_image = None
            self.status_var.set("No compatible images found in the selected folder.")

    def select_folder(self):
        chosen_dir = filedialog.askdirectory(initialdir=self.wallpapers_dir)
        if chosen_dir:
            self.load_images_from_folder(chosen_dir)

    def on_select_image_from_list(self, event):
        selection = self.listbox.curselection()
        if selection:
            self.current_index = selection[0]
            img_path = self.image_files[self.current_index]
            self.update_preview(img_path)

    def update_preview(self, img_path):
        try:
            img = Image.open(img_path)
            img.thumbnail((320, 220), Image.Resampling.LANCZOS)
            self.preview_image = ImageTk.PhotoImage(img)
            self.preview_label.config(image=self.preview_image, text="")
        except Exception as e:
            self.preview_label.config(image="", text="Failed to load preview")
            self.preview_image = None

    def apply_current_wallpaper(self):
        if not self.image_files:
            messagebox.showwarning("Warning", "No wallpapers available to set.")
            return

        img_path = self.image_files[self.current_index]
        self.set_wallpaper(img_path)

    def set_wallpaper(self, img_path):
        try:
            # Convert image to BMP in temp folder for 100% reliable Windows wallpaper application
            img = Image.open(img_path)
            temp_bmp = os.path.join(tempfile.gettempdir(), "skywallpaper_current.bmp")
            img.save(temp_bmp, "BMP")

            # Windows API call (SPI_SETDESKWALLPAPER = 20)
            result = ctypes.windll.user32.SystemParametersInfoW(20, 0, temp_bmp, 3)
            if result:
                filename = os.path.basename(img_path)
                self.status_var.set(f"Wallpaper set successfully: {filename}")
            else:
                raise ctypes.WinError()
        except Exception as e:
            messagebox.showerror("Wallpaper Error", f"Failed to set desktop wallpaper:\n{e}")
            self.status_var.set("Failed to set wallpaper.")

    def next_wallpaper(self):
        if not self.image_files:
            return
        self.current_index = (self.current_index + 1) % len(self.image_files)
        self.listbox.selection_clear(0, tk.END)
        self.listbox.selection_set(self.current_index)
        self.listbox.see(self.current_index)
        img_path = self.image_files[self.current_index]
        self.update_preview(img_path)
        self.apply_current_wallpaper()

    def prev_wallpaper(self):
        if not self.image_files:
            return
        self.current_index = (self.current_index - 1) % len(self.image_files)
        self.listbox.selection_clear(0, tk.END)
        self.listbox.selection_set(self.current_index)
        self.listbox.see(self.current_index)
        img_path = self.image_files[self.current_index]
        self.update_preview(img_path)
        self.apply_current_wallpaper()

    def random_wallpaper(self):
        if not self.image_files:
            return
        if len(self.image_files) > 1:
            new_index = self.current_index
            while new_index == self.current_index:
                new_index = random.randint(0, len(self.image_files) - 1)
            self.current_index = new_index
        else:
            self.current_index = 0

        self.listbox.selection_clear(0, tk.END)
        self.listbox.selection_set(self.current_index)
        self.listbox.see(self.current_index)
        img_path = self.image_files[self.current_index]
        self.update_preview(img_path)
        self.apply_current_wallpaper()

    def toggle_auto_rotate(self):
        if self.auto_rotate_var.get():
            self.schedule_next_rotation()
            self.status_var.set("Auto-rotation enabled.")
        else:
            if self.auto_rotate_job:
                self.root.after_cancel(self.auto_rotate_job)
                self.auto_rotate_job = None
            self.status_var.set("Auto-rotation disabled.")

    def schedule_next_rotation(self):
        if not self.auto_rotate_var.get():
            return
        
        try:
            minutes = float(self.interval_spin.get())
            if minutes < 0.1:
                minutes = 0.1
        except ValueError:
            minutes = 10

        interval_ms = int(minutes * 60 * 1000)
        self.random_wallpaper()

        # Reschedule using non-blocking root.after timer
        self.auto_rotate_job = self.root.after(interval_ms, self.schedule_next_rotation)


if __name__ == "__main__":
    root = tk.Tk()
    app = SkyWallpaperApp(root)
    root.mainloop()